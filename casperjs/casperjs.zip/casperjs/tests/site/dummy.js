document.write('foo');
